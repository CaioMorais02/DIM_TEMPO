create database dw_lowlatency

use dw_lowlatency

