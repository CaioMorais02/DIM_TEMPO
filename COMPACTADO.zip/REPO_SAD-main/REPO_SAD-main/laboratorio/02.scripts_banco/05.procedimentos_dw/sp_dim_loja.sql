create or alter procedure sp_dim_loja(@data_carga datetime)
as
begin
	DECLARE @ID_LOJA, @DT_CARGA
	DECLARE C_DIM_LOJA CURSOR FOR
	SELECT ID_LOJA FROM DIM_LOJA

	OPEN C_DIM_LOJA
	FETCH C_DIM_LOJA INTO @ID_LOJA

	IF @ID_LOJA IS NULL
	BEGIN
		
	END

	ELSE
	BEGIN

	END
end



-- Teste

exec sp_dim_loja '20230321'

select * from dim_loja